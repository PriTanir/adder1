use std::convert::TryInto;
use crate::syntax::{Exp, Span, Prim1};
use crate::asm::{instrs_to_string};
use crate::asm::{Instr, Reg, Arg64, Arg32, Reg32, MovArgs, BinArgs, MemRef};

// The possible error messages for the compiler
#[derive(Debug, PartialEq, Eq)]
pub enum CompileErr {
    // The location here is the Span of unbound variable
    UnboundVariable{ unbound: String, location: Span },

    // The Span here is the Span of the let-expression that has the duplicated bindings
    DuplicateBinding{ duplicated_name: String, location: Span },
}

use std::fmt;
use std::fmt::Display;

impl Display for CompileErr {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
	match self {
	    CompileErr::UnboundVariable{ unbound, location } => write!(f, "Unbound variable {} at {}", unbound, location),
	    CompileErr::DuplicateBinding{ duplicated_name, location } => write!(f, "Variable {} defined twice in let-expression at {}", duplicated_name, location),
	}
    }
}

// You may or may not find the following function useful.
//
// If you use it, make sure you have good reason why the .unwap() will
// not fail.
fn usize_to_i32(x: usize) -> i32 {
    x.try_into().unwrap()
}

// Finds the binding in the environment with the highest index
fn get(env: &[(&str, i32)], x: &str) -> Option<i32> {
    for (y,n) in env.iter().rev() {
        if x == *y {
            return Some(*n);
        }
    }
    None
}

/*
 * The lifetime 'exp here says that the string slices in the
 * environment live as long as the input expression. This allows you
 * to put references to the strings in the input expression into the
 * environment.
 */

 
fn compile_with_env<'exp>(e: &'exp Exp<Span>, mut env: Vec<(&'exp str, i32)>) -> Result<Vec<Instr>, CompileErr> {
    
    match e {
        Exp<a>::Num(n,a) => {
            Ok(vec![ Instr::Mov(MovArgs::ToReg(Reg::Rax, Arg64::Imm(*n)))] )
        }
        Exp<a>::Var(s,a) =>{ 
            let mut is = compile_with_env(e,env);
            //use a to get location of variable on stack and load that into rax
            is.push(Instr::Mov(MovArgs::ToReg(Reg::Rax, Arg64::Mem {reg:Rsp, offset: offset})))
            Ok(is)
        }
        //doubt: Is the add1 and sub1 case right - what is Ann and how to use it here?
    Exp<a>::Prim1(Prim1::Add1,e,a)=> {
          let mut is = compile_with_env(e,env);
          is.push(Instr::Add(BinArgs::ToReg(Reg::Rax, 1)))
          Ok(is)
        }
        Exp<a>::Prim1(Prim1::Sub1,e,a) => {
            //check Unbounded for add and subtract
            //pass a to error constructors
          let mut is = compile_with_env(e,env);
          is.push(Instr::Sub(BinArgs::ToReg(Reg::Rax, 1)))
          Ok(is)
        }
        Exp<a>::Let(x, e1, e2) => {
            //doubt: how to do error checking first using DuplicateBinding
            //check if x has duplicates, every variable name in x is defined
            // Section 5 Rust tips - use hashSet
            let mut is = compile_with_env(e1, env.clone());
            let offset =  env.len() + 1 // doubt: how to Calculate the offset from env - is this right?
            env.push((&String::from(x), offset));
            is.push(Instr::Mov(MovArgs::ToMem(MemRef { reg: Reg::Rsp, offset: offset }, Reg32::Reg{Reg::Rax})));
            is.extend(compile_with_env(e2, env.clone()));
            Ok(is)
          }
      }
}

fn compile_to_instrs(e: &Exp<Span>) -> Result<Vec<Instr>, CompileErr> {
    let mut is = compile_with_env(e, Vec::new())?;
    is.push(Instr::Ret);
    Ok(is)
}

pub fn compile_to_string(e: &Exp<Span>) -> Result<String, CompileErr> {
    Ok(format!("\
        section .text
        global start_here
start_here:
{}       
", instrs_to_string(&compile_to_instrs(e)?)))
}
